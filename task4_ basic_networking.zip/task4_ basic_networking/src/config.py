# config.py

# The server URL where requests will be sent
SERVER_URL = "http://127.0.0.1:5000/api"  # Replace with your actual server URL

# The API token for authentication (replace with your actual token)
API_TOKEN = "http://127.0.0.1:5000/api"
